package tron;

import java.awt.Color;
import java.awt.Graphics;

/**
 * Classe representant une moto dans le jeu. 
 * Gère le comportement de la moto : deplacement, gestion des obstacles, etc. 
 * @author Philippe Meseure
 * @version 1.0
 */
public class Moto {
  /**
   * Lien vers le plateau du jeu.
   */
  private final Plateau plateau;
  /**
   * Identifiant de la moto, forcément un octet, afin de limiter la taille
   * de stockage du tableau (lorsqu'une moto passe sur une case du plateau,
   * il y laisse sa trace, via son identifiant).
   */
  private final byte id;
  /**
   * Couleur de la moto.
   */
  private final Color couleur;
  /**
   * Position actuelle de la moto (attribut d'etat).
   */
  private int x,y;
  /**
   * Direction de deplacement (attribut d'etat).
   */
  private Direction dir;
  /**
   * Indication d'activite de la moto (attribut d'etat).
   * Vaut false si la moto a perdu.
   */
  private boolean actif;

  /**
   * Constructeur
   * @param plateau Plateau du jeu.
   * @param id Identifiant de la moto.
   * @param couleur Couleur de la moto.
   * @param x Colonne de depart de la moto.
   * @param y Ligne de depart de la moto.
   */
  public Moto(Plateau plateau,byte id,Color couleur,int x,int y) {
    this.id=id;
    this.plateau=plateau;
    this.x=x;
    this.y=y;
    this.couleur=couleur;
    this.dir=Direction.AUCUNE;
    this.actif=true;
    // On marque tout de suite le plateau avec la trace de la moto
    this.plateau.setTrace(id, x, y);
  }
  
  /**
   * Accesseur pour la couleur.
   * @return Couleur de la moto.
   */
  public Color getCouleur() {
    return this.couleur;
  }
  
  /**
   * Accesseur sur l'etat d'activite de la moto.
   * @return True si moto encore active (=pas détruite).
   */
  public boolean estActif() {
    return this.actif;
  }
  
  /**
   * Accesseur permettant de savoir si la moto est immobile.
   * Cela n'est possible qu'a la creation de la moto. Elle est forcement
   * mobile ensuite.
   * @return True si la moto est immobile.
   */
  public boolean estEnAttente() {
    return this.dir==Direction.AUCUNE;
  }

  /**
   * Permet de modifier la direction de deplacement en tournant la
   * moto vers la droite.
   */
  public void aDroite() {
    this.dir=this.dir.aDroite();
  }
  /**
   * Permet de modifier la direction de deplacement en tournant la
   * moto vers la gauche.
   */
  public void aGauche() {
    this.dir=this.dir.aGauche();
  }
  /**
   * Permet de specifier la position de depart de la moto.
   * Ne fonctionne que si la moto est immobile.
   */
  public void demarre(Direction d) {
    if (this.dir==Direction.AUCUNE) this.dir=d;
  }

  /**
   * Routine permettant à la moto d'avancer d'un pas dans sa direction courante.
   */
  public void avance() {
    // Si la moto est detruite ou immobile, pas de deplacement
    if (!estActif() || estEnAttente()) return;
    int dx=this.dir.dx(),dy=this.dir.dy();
    // calcul des nouvelles positions
    int x1=this.x+dx,y1=this.y+dy;
    // validation des nouvelles positions
    if ( x1<0 || x1>=plateau.getTailleX() || y1<0 || y1>=plateau.getTailleY()
            || (plateau.getTrace(x1, y1)!=0)) {
      this.actif=false; // obstacle rencontre... la moto est detruite !
    }
    else {
      // Deplacement valide, on marque la position sur le plateau
      this.x=x1; this.y=y1;
      plateau.setTrace(this.id,this.x,this.y);
    }
  }

  /**
   * Routine pour afficher la moto dans la fenetre.
   * @param display Fenetre dans laquelle la moto doit s'afficher.
   */
  public void dessine(TronInterface display) {
    Graphics g=display.getDisplay();
    // recuperation des coordonnees ecran de la moto
    int xecran=display.convertX(this.x);
    int yecran=display.convertY(this.y);
    // On efface le "X" deja present
    g.setColor(Plateau.couleur_fond);
    g.drawString("X",xecran,yecran);
    // On affiche la moto, en fonction de son etat
    g.setColor(this.couleur);
    if (estActif())
      g.drawString("O",xecran,yecran);
    else
      g.drawString("*",xecran,yecran);
  }  
}
