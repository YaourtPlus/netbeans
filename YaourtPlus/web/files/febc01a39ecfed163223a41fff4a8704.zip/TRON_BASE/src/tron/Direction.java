package tron;

/**
 * Enumeration pour la direction de deplacement des motos
 * Surcharge des methodes pour chaque valeur de l'enumation, pour la
 * souplesse d'utilisation. Le cas de l'immobilite est egalement prevu.
 * @author Philippe Meseure
 * @version 1.0
 */
public enum Direction {
  AUCUNE {
    @Override public Direction aDroite() { return AUCUNE; }
    @Override public Direction aGauche() { return AUCUNE; }
  },
  NORD {
    @Override public Direction aGauche() { return OUEST; }
    @Override public int dy() { return -1; }
  },
  EST {
    @Override public int dx() { return 1; }
  },
  SUD {
    @Override public int dy() { return 1; }
  },
  OUEST {
    @Override public Direction aDroite() { return NORD; }
    @Override public int dx() { return -1; }
  };
  /**
   * Membre statique qui enumere toutes les valeurs de l'enumation dans l'ordre
   * Permet de passer a la valeur suivante ou precedente.
   */
  static Direction valeurs[]=Direction.values();
  /**
   * Fournit la direction apres avoir tourne vers la droite.
   * NORD devient EST, EST devient SUD, etc.
   * @return La direction a droite de la direction courante.
   */
  public Direction aDroite() {
    return Direction.valeurs[this.ordinal()+1];
  }
  /**
   * Fournit la direction apres avoir tourne vers la gauche.
   * NORD devient OUEST, EST devient NORD, etc.
   * @return La direction a gauche de la direction courante.
   */
  public Direction aGauche() {
    return Direction.valeurs[this.ordinal()-1];
  }
  /**
   * Fournit le deplacment en x correspondant a la direction courante.
   * Par exemple, +1 pour EST, -1 pour OUEST. Par defaut, c'est 0.
   * @return Le deplacement en colonnes.
   */
  public int dx() {
    return 0;
  }
  /**
   * Fournit le deplacment en y correspondant a la direction courante.
   * Par exemple, -1 pour NORD, +1 pour SUD. Par defaut, c'est 0.
   * @return Le deplacement en lignes.
   */
  public int dy() {
    return 0;
  }
}
