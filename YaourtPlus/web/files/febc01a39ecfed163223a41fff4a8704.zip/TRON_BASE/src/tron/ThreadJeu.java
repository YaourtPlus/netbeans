package tron;

/**
 * Classe pour que le jeu tourne dans un thread. Cela est impose par l'applet
 * java (animation obligatoirement geree dans un thread a part).
 * @author Philippe Meseure
 * @version 1.0
 */
public class ThreadJeu extends Thread {
  /**
   * Lien vers le plateau de jeu
   */
  private final Plateau plateau;
  /**
   * Lien vers la fenetre d'affichage (exemple : applet)
   */
  private final TronInterface display;
  
  /**
   * Constructeur
   * @param disp Fenetre d'affichage (exemple : applet)
   * @param plateau Plateau du jeu
   */
  public ThreadJeu(TronInterface disp,Plateau plateau) {
    this.display=disp;
    this.plateau=plateau;
  }
  
  /**
   * Boucle principale du jeu : avance d'un pas dans le jeu puis demande
   * d'affichage. C'est la routine executee lors du lancement du thread.
   */
  @Override public void run() {
    while(true) {
      this.plateau.pas();  // un pas de jeu
      this.display.repaint(); // Puisque le jeu a avance,
      // on met a jour l'affichage
      try {
        Thread.sleep(50); /* permet de ralentir le jeu...
         * On peut moduler cette attente pour accelerer */
      }
      catch(Exception e) {
      }
    }
  }
}
