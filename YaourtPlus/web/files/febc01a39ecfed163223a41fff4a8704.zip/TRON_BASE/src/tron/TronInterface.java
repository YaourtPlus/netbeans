package tron;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Frame;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Classe d'interface, i.e. representant la fenetre.
 * Attention : pas une approche MVC.
 * La partie controle est ici, mais la partie vue fait partie du modèle
 * @author Philippe Meseure
 */
public class TronInterface extends Applet implements KeyListener {
  private static final long serialVersionUID=1L;
  /**
   * Lien vers le plateau de jeu
   */
  private final Plateau plateau;
  /**
   * Lien vers la moto controle via le clavier (une seule moto controlable)
   */
  private Moto moto;
  /**
   * Buffer graphique arriere permettant un affichage à double buffer
   * (evite de voir le trace, l'affichage se fait une fois l'image
   * entierement tracee)
   */
  private Image backbuffer;
  /**
   * Activation de l'affichage de l'aide
   */
  private boolean aide;

  /**
   * Constructeur
   * @param plateau Plateau du jeu
   */
  public TronInterface(Plateau plateau) {
    this.plateau=plateau;
    this.moto=null;
    this.backbuffer=null;
    this.aide=true;
  }

  /**
   * Lancement de l'applet. Permet d'initialiser les choses impossibles a
   * initialiser dans le constructeur. Par exemple, tout ce qui depend de la
   * taille de la fenetre (non cree dans le constructeur, car applet peut
   * dependre d'une page HTML)
   */
  @Override public void init() {
    // Creation du backbuffer pour ne pas voir les traces s'executer
    Dimension d=getSize();
    this.backbuffer=createImage(d.width,d.height);
    // Pour pouvoir recuperer les evenements clavier
    addKeyListener(this);
    // Creation du thread du jeu, pour l'animation
    // (forcement a part, non gere par l'applet)
    ThreadJeu threadjeu=new ThreadJeu(this,plateau);
    threadjeu.start();
  }

  /**
   * Permet de creer une fenetre si aucune page HTML d'hebergement de l'applet
   * n'a ete prevue.
   */
  public void creeFenetre() // Cas ou applet n'est pas dans une page HTML
  {
    Frame f=new Frame("Tron");    
    f.add("Center",this);
    f.setSize(this.plateau.getTailleX()*10+10,
              this.plateau.getTailleY()*10+30);
    // La fenetre comprend egalement un titre, etc. d'où quelques pixels
    // a ajouter
    f.setVisible(true);
  }

  /**
   * Convertit une colonne en une position x en pixels a l'ecran.
   * Chaque caractere occupe 10 pixels en largeur.
   * @param x Numero de colonne de caractères
   * @return La position x en pixels
   */
  public int convertX(int x) { return x*10; }

  /**
   * Convertit une ligne en une position y en pixels a l'ecran.
   * Chaque caratere occupe 10 pixels en hauteur.
   * @param y Numero de ligne en caractere
   * @return La position y en pixels
   */
  public int convertY(int y) { return y*10+10; }

  /**
   * Fournit la zone graphique dans laquelle effectuer les tracer. Cette
   * routine permet une certaine genericite, car ainsi, l'interface utilisee
   * par le jeu pourrait etre tout autre chose qu'une applet, du moment que
   * les aspects graphiques soient geres par awt.
   * Pour l'animation, il est conseille de travailler en double buffer.
   * Aussi, la zone de trace est un buffer arriere, affiche une fois le trace
   * termine.
   * @return La zone graphique
   */
  public Graphics getDisplay() { return this.backbuffer.getGraphics(); }

  /**
   * Permet d'afficher l'aide, en surimpression sur l'ecran.
   * @param g La zone graphique pour l'affichage.
   */
  private void afficheAide(Graphics g) {
    int taille=15,y=50-taille,x=50;
    g.setColor(Color.white);
    g.drawString("Aide",x,y+=taille);
    g.drawString("<h> : affichage/effacement de l'aide",x,y+=taille);
    g.drawString("<s>: demarrage en une position aléatoire",x,y+=taille);
    g.drawString("<haut,bas,gauche,droite> : direction de demarrage",x,y+=taille);
    g.drawString("<gauche,droite> : tourner",x,y+=taille);
    g.drawString("<echap> : quitter",x,y+=taille);
  }

  /**
   * Routine abstraite imposee par Applet, rien a faire ici
   */
  @Override public void destroy() {
  }

  /**
   * Gere l'affichage du contenu graphique de la fenetre. Est appelee lorsqu'un
   * evenement d'affichage est recu par la fenetre.
   * @param g Zone graphique pour l'affichage
   */
  @Override public void paint(Graphics g) {
    update(g);
  }

  /**
   * Gere la mise a jour de l'affichage. Ici, on choisit de faire un affichage
   * complet.
   * @param g Zone graphique pour l'affichage.
   * Mais comme c'est le front buffer, on ne dessine rien dedans.
   */
  @Override public void update(Graphics g) {
    // Recuperation du backbuffer pour faire le trace
    Graphics backg=this.getDisplay();
    // Dessin du jeu
    this.plateau.dessine(this);
    // Ajout eventuel du message d'aide
    if (this.aide) afficheAide(backg);
    // Le backbuffer est recopie integralement dans le frontbuffer
    g.drawImage(this.backbuffer,0,0,this);
  }

  /**
   * Interception d'utilisation d'une touche.
   * Il est possible de surcharger KeyTyped, KeyPressed ou KeyRelease
   * KeyPressed est prefere, pour une meilleure reactivite, car on reagit des
   * l'appui de la touche.
   * La routine est en deux parties, elle gere d'abord les touches
   * correspondant a des caracteres (utilisation du code ASCII), puis les
   * touches qui ne sont pas des caracteres (utilisation du code de touche).
   * @param e Evenement contenant la touche
   */
  @Override public void keyPressed(KeyEvent e)
  {
    char c=e.getKeyChar();
    if (c!=KeyEvent.CHAR_UNDEFINED) {
      c=Character.toLowerCase(c); // Utile ??
      switch(c) {
        case 27: // 27 est le caractere correspondant a <echap>
          System.exit(0); break;
        case 's': // Creation d'une moto, pour demarrer une nouvelle partie
          if (moto==null || !moto.estActif())
            moto=plateau.creeMoto();
          break;
        case 'h': // demande d'affichage de l'aide (en bascule)
          aide=aide^true;
          break;
      }
    }
    else {
      /*
       * Gestion des touches ne correspondant pas a un caractere
       * (fleches de déplacement)
       * Pour chaque deplacement, il faut faire la difference entre le
       * demarrage (toutes les touches sont actives) ou le fonctionnement
       * en mobilite (seulement tourner a droite ou a gauche)
       */
      int key=e.getKeyCode();
      switch(key)
      {
        case KeyEvent.VK_UP:
          if (moto!=null && moto.estEnAttente()) moto.demarre(Direction.NORD);
          break;
        case KeyEvent.VK_DOWN:
          if (moto!=null && moto.estEnAttente()) moto.demarre(Direction.SUD);
          break;
        case KeyEvent.VK_LEFT:
          if (moto!=null) {
            if (moto.estEnAttente()) moto.demarre(Direction.OUEST);
            else moto.aGauche();
          }
          break;
        case KeyEvent.VK_RIGHT:
          if (moto!=null) {
            if (moto.estEnAttente()) moto.demarre(Direction.EST);
            else moto.aDroite();
          }
          break;
      }
    }
  }
  /**
   * Routine ignoree car le relachement d'une touche n'a pas d'effet.
   * @param e Evenement correspondant a une touche
   */
  @Override public void keyReleased(KeyEvent e) {}
  /**
   * Routine ignoree car le relachement d'une touche n'a pas d'effet.
   * @param e Evenement correspondant a une touche
   */
  @Override public void keyTyped(KeyEvent e) {}
}
