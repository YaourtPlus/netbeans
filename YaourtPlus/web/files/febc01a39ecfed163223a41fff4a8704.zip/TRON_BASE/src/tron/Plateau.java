package tron;

import java.awt.Graphics;
import java.awt.Color;
import java.util.HashMap;

/**
 * Classe designant le plateau de jeu.
 * Le plateau est modelise par un tableau de bytes, chaque case du tableau
 * correspond a une case du plateau. Si la case contient autre chose que 0, il
 * s'agit de l'identifiant d'une moto qui est passee par cette case.
 * @author Philippe Meseure
 * @version 1.0
 */
public class Plateau {
  public static final Color couleur_fond=Color.darkGray;
  /**
   * Taille du plateau.
   * Les cases du plateau sont numerotees entre 0 et taillex-1 et 0 et tailley-1.
   */
  private final int taillex,tailley;
  /**
   * Contient les cases du plateau. Une case vide contient 0.
   * Si le contenu est non nul, cela signifie qu'une moto est passee par la.
   * Il est alors impossible a une autre moto de passer par cette case.
   * Le choix de <I>byte</I> limite à 255 motos, ou plus précisément 255
   * tentatives car un utilisateur peut demander une nouvelle moto si la
   * precedente est detruite, mais la nouvelle moto aura un identifiant different
   * (ce choix peut etre reconsidere si on le trouve trop limitatif,
   * mais cela implique une gestion differente de la liste des motos
   * voire de la classe moto (= recyclage d'une moto...).
   * @see Moto
   */
  private byte[][] cases;
  /**
   * Collection des motos.
   * L'id de la moto est utilise comme cle dans la hashmap.
   */
  private HashMap<Byte,Moto> motos;
  /**
   * Prochain id libre. Les id sont distribues dans l'ordre croissant.
   */
  private byte id_suivant=1;
  
  /**
   * Constructeur
   * @param largeur Taille en colonnes du plateau.
   * @param hauteur Taille en lignes du plateau.
   */
  public Plateau(int largeur,int hauteur) {
    this.taillex=largeur;
    this.tailley=hauteur;
    this.cases=new byte[tailley][taillex];
    this.videPlateau();
    this.motos=new HashMap<Byte,Moto>();
  }
  
  /**
   * Permet de vider le plateau lors du demarrage du jeu.
   */
  private void videPlateau() {
    for(int y=0;y<this.tailley;y++)
      for(int x=0;x<this.taillex;x++) {
        cases[y][x]=0;
      }
  }
  
  /**
   * Accesseur sur la taille en colonnes.
   * @return Nombre de colonnes du plateau.
   */
  public int getTailleX() { return this.taillex; }
  /**
   * Accesseur sur la taille en ligne.
   * @return Nombre de lignes du plateau.
   */
  public int getTailleY() { return this.tailley; }

  /**
   * Fournit la trace a l'emplacement x,y.
   * @param x Colonne de la case inspectee.
   * @param y Ligne de la case inspectee.
   * @return La trace a l'emplacement x,y
   */
  public byte getTrace(int x,int y) {
    if (x>=0 && x<taillex && y>=0 && y<tailley)
      return this.cases[y][x];
    else return 0;
  }
  
  /**
   * Positionne la trace a l'emplacement x,y.
   * Ne fonctionne que si aucune trace n'est deja presente.
   * @param id Trace a laisser. 
   * @param x Colonne de la case a modifier.
   * @param y Ligne de la case a modifier.
   */
  public void setTrace(byte id,int x,int y) {
    if (x>=0 && x<taillex && y>=0 && y<tailley && this.cases[y][x]==0)
      this.cases[y][x]=id;
  }
  
  /** 
   * Fournit un nouvel id pour une moto. Le premier id fourni est 1,
   * puis 2, etc.
   * Attention, aucune protection si debordement...
   * @return Nouvel id
   */
  public byte getNouvMotoId() {
    if (this.id_suivant==0)  this.id_suivant=1; 
    return this.id_suivant++;
  }

  /**
   * Cree une nouvelle moto (avec un nouvel id), a une position aleatoire
   * et incorpore cette moto dans la liste courante des motos.
   * @return Une nouvelle moto, avec un nouvel id.
   */
  public Moto creeMoto() {
    // Choix de la position
    int x,y;
    do {
      x=(int)(Math.random()*this.taillex);
      y=(int)(Math.random()*this.tailley);
    } while(this.cases[y][x]!=0);

    // Choix de la couleur
    float r,v,b;
    do {
      r=(float)Math.random();
      v=(float)Math.random();
      b=(float)Math.random();
    } while (r+v+b<2.0F);
    Color couleur=new Color(r,v,b);
    
    // determination d'un nouvel identifiant
    byte id=getNouvMotoId();

    // Creation de la moto
    Moto moto=new Moto(this,id,couleur,x,y);

    // Ajout de la moto dans la hashmap
    this.motos.put(id, moto);
    return moto;
  }

  /**
   * Avance d'un pas dans le jeu.
   * Cela consiste surtout a faire avancer d'un pas toutes les motos actives
   */
  public void pas() {
    for(Moto moto:this.motos.values())
    {
      moto.avance();
    }
  }

  /**
   * Dessine le plateau, i.e. pour chaque case non nulle,  affiche une
   * trace (X) de la couleur de la moto qui l'a laissee. Dessine ensuite
   * l'ensemble des motos.
   * @param display Fenetre de l'application dans laquelle les affichages
   * doivent se faire
   */
  public void dessine(TronInterface display) {
    Graphics g=display.getDisplay();
    
    // Remplissage de la fenetre
    g.setColor(couleur_fond);
    g.fillRect(0,0,this.taillex*10,this.tailley*10);

    // Parcours de chaque case, et affichage de la trace correspondante
    // s'il y a trace
    for(int y=0;y<this.tailley;y++)
      for(int x=0;x<this.taillex;x++) {
        byte num=this.cases[y][x];
        if (num!=0) {
          g.setColor(this.motos.get(num).getCouleur());
          g.drawString("X",display.convertX(x),display.convertY(y));
        }
      }
    for(Moto moto:this.motos.values()) {
      moto.dessine(display);
    }
  }
}
