package tron;

/**
 * Classe principale du jeu Tron. Cree la fenetre, le jeu et lance le tout.
 * @author Philippe Meseure
 * @version 1.0
 */
public class Tron {
  /**
   * Procedure principale si lancement direct sans page HTML
   * @param args Arguments de lancement en ligne de commandes
   */
  static public void main(String[] args)
  {
    Plateau plateau=new Plateau(100,100); // Taille du plateau par defaut
    TronInterface interf=new TronInterface(plateau);
    interf.creeFenetre();
    interf.init();
    interf.start();
  }  
}
